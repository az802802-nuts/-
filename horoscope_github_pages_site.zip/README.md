
# Horoscope Line Style (続き対応)

ワンクリックで遊べるLINE風の「今日の星座占い」です。
- 「🎰 占う」→ 4つ表示
- 「▶ 続きを占う」→ 次の4つ…→ 12星座コンプリート
- 「🔁 再抽選」→ 並びをリセット

## 公開（GitHub Pages）
1. GitHubで新規リポジトリを作成（例: `horoscope-line`）
2. このZIPをアップロードして解凍（`index.html`がリポジトリ直下にある状態に）
3. Settings → Pages → Branch を `main`、`/ (root)` に設定して保存
4. 数分後に `https://<ユーザー名>.github.io/horoscope-line/` で公開されます

